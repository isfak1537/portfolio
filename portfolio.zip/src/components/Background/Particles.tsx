import { motion } from "framer-motion";

const particles = Array.from({ length: 35 });

export default function Particles() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {particles.map((_, i) => (
        <motion.span
          key={i}
          initial={{
            opacity: 0,
            y: Math.random() * 900,
            x: Math.random() * 1800,
          }}
          animate={{
            opacity: [0.15, 0.6, 0.15],
            y: [null, -120],
          }}
          transition={{
            duration: 5 + Math.random() * 6,
            repeat: Infinity,
            repeatType: "reverse",
          }}
          className="absolute h-1 w-1 rounded-full bg-cyan-300"
        />
      ))}
    </div>
  );
}